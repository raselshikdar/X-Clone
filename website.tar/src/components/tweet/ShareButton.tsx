"use client"

import * as React from "react"
import { Share, Link2, Mail, MessageCircle } from "lucide-react"
import { cn } from "@/lib/utils"
import { toast } from "@/hooks/use-toast"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from "@/components/ui/button"

interface ShareButtonProps {
  tweetId: string
  authorUsername?: string
  size?: "sm" | "md" | "lg"
  className?: string
}

export function ShareButton({
  tweetId,
  authorUsername,
  size = "md",
  className,
}: ShareButtonProps) {
  const [copied, setCopied] = React.useState(false)
  
  const tweetUrl = typeof window !== "undefined"
    ? `${window.location.origin}/${authorUsername || 'status'}/${tweetId}`
    : `/${authorUsername || 'status'}/${tweetId}`
  
  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(tweetUrl)
      setCopied(true)
      toast({
        title: "Link copied",
        description: "The link has been copied to your clipboard.",
      })
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy link. Please try again.",
        variant: "destructive",
      })
    }
  }
  
  const handleShareVia = (platform: string) => {
    const text = "Check out this tweet!"
    let url = ""
    
    switch (platform) {
      case "twitter":
        url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(tweetUrl)}`
        break
      case "facebook":
        url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(tweetUrl)}`
        break
      case "linkedin":
        url = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(tweetUrl)}`
        break
      case "reddit":
        url = `https://reddit.com/submit?url=${encodeURIComponent(tweetUrl)}&title=${encodeURIComponent(text)}`
        break
    }
    
    window.open(url, "_blank", "width=600,height=400")
  }
  
  const handleShareNative = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Check out this tweet",
          url: tweetUrl,
        })
      } catch (error) {
        // User cancelled or error
        console.log("Share cancelled or failed")
      }
    } else {
      handleCopyLink()
    }
  }
  
  const sizeClasses = {
    sm: "size-[14px]",
    md: "size-[18px]",
    lg: "size-[22px]",
  }
  
  const buttonSizeClasses = {
    sm: "p-1.5 -m-1.5",
    md: "p-2 -m-2",
    lg: "p-2.5 -m-2.5",
  }
  
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          className={cn(
            "flex items-center gap-1 group",
            "rounded-full",
            "hover:bg-twitter-blue/10",
            "text-twitter-secondary dark:text-twitter-secondary-dark",
            "hover:text-twitter-blue",
            "transition-colors duration-200",
            buttonSizeClasses[size],
            className
          )}
        >
          <Share className={sizeClasses[size]} />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="min-w-[200px]">
        <DropdownMenuItem onClick={handleCopyLink} className="gap-3">
          <Link2 className="size-5" />
          {copied ? "Link copied!" : "Copy link"}
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => handleShareVia("twitter")} className="gap-3">
          <svg className="size-5" viewBox="0 0 24 24" fill="currentColor">
            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
          </svg>
          Share via X
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleShareVia("facebook")} className="gap-3">
          <svg className="size-5" viewBox="0 0 24 24" fill="currentColor">
            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
          </svg>
          Share via Facebook
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleShareVia("linkedin")} className="gap-3">
          <svg className="size-5" viewBox="0 0 24 24" fill="currentColor">
            <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
          </svg>
          Share via LinkedIn
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleShareVia("reddit")} className="gap-3">
          <svg className="size-5" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0zm5.01 4.744c.688 0 1.25.561 1.25 1.249a1.25 1.25 0 0 1-2.498.056l-2.597-.547-.8 3.747c1.824.07 3.48.632 4.674 1.488.308-.309.73-.491 1.207-.491.968 0 1.754.786 1.754 1.754 0 .716-.435 1.333-1.01 1.614a3.111 3.111 0 0 1 .042.52c0 2.694-3.13 4.87-7.004 4.87-3.874 0-7.004-2.176-7.004-4.87 0-.183.015-.366.043-.534A1.748 1.748 0 0 1 4.028 12c0-.968.786-1.754 1.754-1.754.463 0 .898.196 1.207.49 1.207-.883 2.878-1.43 4.744-1.487l.885-4.182a.342.342 0 0 1 .14-.197.35.35 0 0 1 .238-.042l2.906.617a1.214 1.214 0 0 1 1.108-.701zM9.25 12C8.561 12 8 12.562 8 13.25c0 .687.561 1.248 1.25 1.248.687 0 1.248-.561 1.248-1.249 0-.688-.561-1.249-1.249-1.249zm5.5 0c-.687 0-1.248.561-1.248 1.25 0 .687.561 1.248 1.249 1.248.688 0 1.249-.561 1.249-1.249 0-.687-.562-1.249-1.25-1.249zm-5.466 3.99a.327.327 0 0 0-.231.094.33.33 0 0 0 0 .463c.842.842 2.484.913 2.961.913.477 0 2.105-.056 2.961-.913a.361.361 0 0 0 .029-.463.33.33 0 0 0-.464 0c-.547.533-1.684.73-2.512.73-.828 0-1.979-.196-2.512-.73a.326.326 0 0 0-.232-.095z" />
          </svg>
          Share via Reddit
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handleShareNative} className="gap-3">
          <MessageCircle className="size-5" />
          Share via DM
        </DropdownMenuItem>
        <DropdownMenuItem className="gap-3">
          <Mail className="size-5" />
          Share via email
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
